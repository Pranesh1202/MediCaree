import { useState, useEffect, useCallback } from 'react';
import {
  LayoutDashboard,
  Users,
  Stethoscope,
  CalendarDays,
  Activity,
  Menu,
  X,
} from 'lucide-react';
import { supabase, type Patient, type Doctor, type AppointmentWithRelations } from '@/lib/supabase';
import { Dashboard } from '@/views/Dashboard';
import { PatientsView } from '@/views/PatientsView';
import { DoctorsView } from '@/views/DoctorsView';
import { AppointmentsView } from '@/views/AppointmentsView';

type View = 'dashboard' | 'patients' | 'doctors' | 'appointments';

const NAV_ITEMS: { id: View; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'patients', label: 'Patients', icon: Users },
  { id: 'doctors', label: 'Doctors', icon: Stethoscope },
  { id: 'appointments', label: 'Appointments', icon: CalendarDays },
];

export default function App() {
  const [view, setView] = useState<View>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [appointments, setAppointments] = useState<AppointmentWithRelations[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    const [pRes, dRes, aRes] = await Promise.all([
      supabase.from('patients').select('*').order('created_at', { ascending: false }),
      supabase.from('doctors').select('*').order('created_at', { ascending: false }),
      supabase
        .from('appointments')
        .select('*, patients(first_name, last_name), doctors(first_name, last_name, specialization)')
        .order('appointment_date', { ascending: true }),
    ]);

    if (pRes.data) setPatients(pRes.data);
    if (dRes.data) setDoctors(dRes.data);
    if (aRes.data) setAppointments(aRes.data as AppointmentWithRelations[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const navItemClass = (id: View) =>
    `flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-all ${
      view === id
        ? 'bg-teal-600 text-white shadow-lg shadow-teal-600/20'
        : 'text-slate-500 hover:bg-slate-100 hover:text-slate-900'
    }`;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Mobile header */}
      <div className="sticky top-0 z-30 flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3 lg:hidden">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-600 text-white">
            <Activity className="h-5 w-5" />
          </div>
          <span className="text-base font-bold tracking-tight">MediCore</span>
        </div>
        <button onClick={() => setSidebarOpen(true)} className="rounded-lg p-2 text-slate-600 hover:bg-slate-100">
          <Menu className="h-5 w-5" />
        </button>
      </div>

      {/* Sidebar overlay (mobile) */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-slate-900/40 backdrop-blur-sm lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex w-72 flex-col border-r border-slate-200 bg-white transition-transform duration-300 lg:translate-x-0 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex items-center justify-between px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-600 text-white shadow-lg shadow-teal-600/30">
              <Activity className="h-5 w-5" />
            </div>
            <div>
              <p className="text-lg font-bold tracking-tight text-slate-900">MediCore</p>
              <p className="text-xs text-slate-400">Hospital Management</p>
            </div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 lg:hidden">
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-1.5 px-4 py-4">
          <p className="px-3 pb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Menu</p>
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setView(item.id);
                  setSidebarOpen(false);
                }}
                className={navItemClass(item.id)}
              >
                <Icon className="h-[18px] w-[18px]" />
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-100 p-4">
          <div className="rounded-xl bg-slate-50 p-4">
            <p className="text-xs font-semibold text-slate-700">System Status</p>
            <div className="mt-2 flex items-center gap-2">
              <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
              <span className="text-xs text-slate-500">All systems operational</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="lg:pl-72">
        <main className="min-h-screen px-4 py-6 sm:px-6 lg:px-10 lg:py-8">
          {view === 'dashboard' && (
            <Dashboard
              patients={patients}
              doctors={doctors}
              appointments={appointments}
              loading={loading}
              onNavigate={setView}
            />
          )}
          {view === 'patients' && <PatientsView patients={patients} loading={loading} onChanged={fetchAll} />}
          {view === 'doctors' && <DoctorsView doctors={doctors} loading={loading} onChanged={fetchAll} />}
          {view === 'appointments' && (
            <AppointmentsView
              appointments={appointments}
              patients={patients}
              doctors={doctors}
              loading={loading}
              onChanged={fetchAll}
            />
          )}
        </main>
      </div>
    </div>
  );
}
