import { useState, useMemo } from 'react';
import { Plus, Search, Pencil, Trash2, Stethoscope, Mail, Phone } from 'lucide-react';
import { supabase, type Doctor } from '@/lib/supabase';
import { DOCTOR_STATUSES, GENDERS, SPECIALIZATIONS } from '@/lib/constants';
import { Badge, Modal, ConfirmDialog, Spinner, EmptyState } from '@/components/ui';
import { FormField, TextInput, Select, inputClass } from '@/components/FormFields';

type Props = {
  doctors: Doctor[];
  loading: boolean;
  onChanged: () => void;
};

type FormState = {
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  specialization: string;
  license_number: string;
  gender: string;
  status: string;
};

const emptyForm: FormState = {
  first_name: '',
  last_name: '',
  email: '',
  phone: '',
  specialization: 'Cardiology',
  license_number: '',
  gender: '',
  status: 'active',
};

export function DoctorsView({ doctors, loading, onChanged }: Props) {
  const [search, setSearch] = useState('');
  const [specFilter, setSpecFilter] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Doctor | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<Doctor | null>(null);

  const filtered = useMemo(() => {
    return doctors.filter((d) => {
      const matchesSearch =
        !search ||
        `${d.first_name} ${d.last_name}`.toLowerCase().includes(search.toLowerCase()) ||
        d.email?.toLowerCase().includes(search.toLowerCase()) ||
        d.license_number?.toLowerCase().includes(search.toLowerCase());
      const matchesSpec = !specFilter || d.specialization === specFilter;
      return matchesSearch && matchesSpec;
    });
  }, [doctors, search, specFilter]);

  const openAdd = () => {
    setEditing(null);
    setForm(emptyForm);
    setError('');
    setModalOpen(true);
  };

  const openEdit = (d: Doctor) => {
    setEditing(d);
    setForm({
      first_name: d.first_name,
      last_name: d.last_name,
      email: d.email ?? '',
      phone: d.phone ?? '',
      specialization: d.specialization,
      license_number: d.license_number ?? '',
      gender: d.gender ?? '',
      status: d.status,
    });
    setError('');
    setModalOpen(true);
  };

  const save = async () => {
    if (!form.first_name.trim() || !form.last_name.trim()) {
      setError('First and last name are required.');
      return;
    }
    if (!form.specialization.trim()) {
      setError('Specialization is required.');
      return;
    }
    setSaving(true);
    setError('');

    const payload = {
      first_name: form.first_name.trim(),
      last_name: form.last_name.trim(),
      email: form.email.trim() || null,
      phone: form.phone.trim() || null,
      specialization: form.specialization,
      license_number: form.license_number.trim() || null,
      gender: form.gender || null,
      status: form.status,
    };

    const res = editing
      ? await supabase.from('doctors').update(payload).eq('id', editing.id)
      : await supabase.from('doctors').insert(payload);

    setSaving(false);
    if (res.error) {
      setError(res.error.message);
      return;
    }
    setModalOpen(false);
    onChanged();
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    await supabase.from('doctors').delete().eq('id', deleteTarget.id);
    setDeleteTarget(null);
    onChanged();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Doctors</h1>
          <p className="mt-1 text-sm text-slate-500">{doctors.length} doctors on staff</p>
        </div>
        <button
          onClick={openAdd}
          className="inline-flex items-center gap-2 rounded-xl bg-teal-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-teal-600/20 transition-colors hover:bg-teal-700"
        >
          <Plus className="h-4 w-4" />
          Add Doctor
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name, email, or license..."
            className={`${inputClass} pl-10`}
          />
        </div>
        <Select value={specFilter} onChange={(e) => setSpecFilter(e.target.value)} className="sm:w-56">
          <option value="">All specializations</option>
          {SPECIALIZATIONS.map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </Select>
      </div>

      {/* Grid */}
      {loading ? (
        <Spinner />
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white">
          <EmptyState icon={<Stethoscope className="h-6 w-6" />} title="No doctors found" message="Try adjusting your search or add a new doctor." />
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((d) => (
            <div
              key={d.id}
              className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-teal-50 text-base font-semibold text-teal-700">
                    {d.first_name[0]}{d.last_name[0]}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">Dr. {d.first_name} {d.last_name}</p>
                    <p className="text-xs text-slate-400">{d.specialization}</p>
                  </div>
                </div>
                <div className="flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                  <button onClick={() => openEdit(d)} className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-teal-600">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button onClick={() => setDeleteTarget(d)} className="rounded-lg p-1.5 text-slate-400 hover:bg-rose-50 hover:text-rose-600">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <div className="mt-4 space-y-2 text-xs text-slate-500">
                {d.email && <p className="flex items-center gap-2"><Mail className="h-3.5 w-3.5 text-slate-400" /> {d.email}</p>}
                {d.phone && <p className="flex items-center gap-2"><Phone className="h-3.5 w-3.5 text-slate-400" /> {d.phone}</p>}
                {d.license_number && <p className="flex items-center gap-2"><Stethoscope className="h-3.5 w-3.5 text-slate-400" /> License: {d.license_number}</p>}
              </div>

              <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-3">
                <span className="text-xs capitalize text-slate-400">{d.gender || '—'}</span>
                <Badge status={d.status} />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Doctor' : 'Add Doctor'}>
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <FormField label="First Name" required>
              <TextInput value={form.first_name} onChange={(e) => setForm({ ...form, first_name: e.target.value })} />
            </FormField>
            <FormField label="Last Name" required>
              <TextInput value={form.last_name} onChange={(e) => setForm({ ...form, last_name: e.target.value })} />
            </FormField>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <FormField label="Email">
              <TextInput type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </FormField>
            <FormField label="Phone">
              <TextInput value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </FormField>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <FormField label="Specialization" required>
              <Select value={form.specialization} onChange={(e) => setForm({ ...form, specialization: e.target.value })}>
                {SPECIALIZATIONS.map((s) => <option key={s} value={s}>{s}</option>)}
              </Select>
            </FormField>
            <FormField label="License Number">
              <TextInput value={form.license_number} onChange={(e) => setForm({ ...form, license_number: e.target.value })} />
            </FormField>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <FormField label="Gender">
              <Select value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
                <option value="">—</option>
                {GENDERS.map((g) => <option key={g} value={g}>{g.charAt(0).toUpperCase() + g.slice(1)}</option>)}
              </Select>
            </FormField>
            <FormField label="Status">
              <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                {DOCTOR_STATUSES.map((s) => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
              </Select>
            </FormField>
          </div>
          {error && <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-600">{error}</p>}
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setModalOpen(false)} className="rounded-lg px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-100">
              Cancel
            </button>
            <button
              onClick={save}
              disabled={saving}
              className="rounded-lg bg-teal-600 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-teal-600/20 transition-colors hover:bg-teal-700 disabled:opacity-50"
            >
              {saving ? 'Saving...' : editing ? 'Save Changes' : 'Add Doctor'}
            </button>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
        title="Delete Doctor"
        message={`Are you sure you want to delete Dr. ${deleteTarget?.first_name} ${deleteTarget?.last_name}? This will also remove all their appointments. This cannot be undone.`}
      />
    </div>
  );
}
