import { useState, useMemo } from 'react';
import { Plus, Search, Pencil, Trash2, CalendarDays, Clock, User, Stethoscope } from 'lucide-react';
import { supabase, type AppointmentWithRelations, type Patient, type Doctor } from '@/lib/supabase';
import { APPOINTMENT_STATUSES } from '@/lib/constants';
import { Badge, Modal, ConfirmDialog, Spinner, EmptyState } from '@/components/ui';
import { FormField, TextInput, Select, TextArea, inputClass } from '@/components/FormFields';

type Props = {
  appointments: AppointmentWithRelations[];
  patients: Patient[];
  doctors: Doctor[];
  loading: boolean;
  onChanged: () => void;
};

type FormState = {
  patient_id: string;
  doctor_id: string;
  appointment_date: string;
  reason: string;
  status: string;
  notes: string;
};

const emptyForm: FormState = {
  patient_id: '',
  doctor_id: '',
  appointment_date: '',
  reason: '',
  status: 'scheduled',
  notes: '',
};

function toLocalInput(dateStr: string) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function AppointmentsView({ appointments, patients, doctors, loading, onChanged }: Props) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<AppointmentWithRelations | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<AppointmentWithRelations | null>(null);

  const filtered = useMemo(() => {
    return appointments.filter((a) => {
      const patientName = `${a.patients?.first_name ?? ''} ${a.patients?.last_name ?? ''}`.toLowerCase();
      const doctorName = `${a.doctors?.first_name ?? ''} ${a.doctors?.last_name ?? ''}`.toLowerCase();
      const matchesSearch =
        !search ||
        patientName.includes(search.toLowerCase()) ||
        doctorName.includes(search.toLowerCase()) ||
        a.reason?.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = !statusFilter || a.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [appointments, search, statusFilter]);

  const openAdd = () => {
    setEditing(null);
    setForm({
      ...emptyForm,
      patient_id: patients[0]?.id ?? '',
      doctor_id: doctors[0]?.id ?? '',
    });
    setError('');
    setModalOpen(true);
  };

  const openEdit = (a: AppointmentWithRelations) => {
    setEditing(a);
    setForm({
      patient_id: a.patient_id,
      doctor_id: a.doctor_id,
      appointment_date: toLocalInput(a.appointment_date),
      reason: a.reason ?? '',
      status: a.status,
      notes: a.notes ?? '',
    });
    setError('');
    setModalOpen(true);
  };

  const save = async () => {
    if (!form.patient_id || !form.doctor_id) {
      setError('Please select a patient and a doctor.');
      return;
    }
    if (!form.appointment_date) {
      setError('Please select a date and time.');
      return;
    }
    setSaving(true);
    setError('');

    const payload = {
      patient_id: form.patient_id,
      doctor_id: form.doctor_id,
      appointment_date: new Date(form.appointment_date).toISOString(),
      reason: form.reason.trim() || null,
      status: form.status,
      notes: form.notes.trim() || null,
    };

    const res = editing
      ? await supabase.from('appointments').update(payload).eq('id', editing.id)
      : await supabase.from('appointments').insert(payload);

    setSaving(false);
    if (res.error) {
      setError(res.error.message);
      return;
    }
    setModalOpen(false);
    onChanged();
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    await supabase.from('appointments').delete().eq('id', deleteTarget.id);
    setDeleteTarget(null);
    onChanged();
  };

  const formatDate = (d: string) =>
    new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

  const formatTime = (d: string) =>
    new Date(d).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Appointments</h1>
          <p className="mt-1 text-sm text-slate-500">{appointments.length} appointments scheduled</p>
        </div>
        <button
          onClick={openAdd}
          className="inline-flex items-center gap-2 rounded-xl bg-teal-600 px-4 py-2.5 text-sm font-semibold text-white shadow-lg shadow-teal-600/20 transition-colors hover:bg-teal-700"
        >
          <Plus className="h-4 w-4" />
          Add Appointment
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by patient, doctor, or reason..."
            className={`${inputClass} pl-10`}
          />
        </div>
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="sm:w-48">
          <option value="">All statuses</option>
          {APPOINTMENT_STATUSES.map((s) => (
            <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
          ))}
        </Select>
      </div>

      {/* List */}
      {loading ? (
        <Spinner />
      ) : filtered.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 bg-white">
          <EmptyState icon={<CalendarDays className="h-6 w-6" />} title="No appointments found" message="Try adjusting your search or schedule a new appointment." />
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((a) => (
            <div
              key={a.id}
              className="group flex flex-col gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition-all hover:shadow-md sm:flex-row sm:items-center sm:justify-between"
            >
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 shrink-0 flex-col items-center justify-center rounded-xl bg-teal-50 text-teal-700">
                  <span className="text-xs font-semibold uppercase">{new Date(a.appointment_date).toLocaleDateString('en-US', { month: 'short' })}</span>
                  <span className="text-lg font-bold leading-none">{new Date(a.appointment_date).getDate()}</span>
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-900">
                    {a.patients?.first_name} {a.patients?.last_name}
                  </p>
                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-slate-400">
                    <span className="flex items-center gap-1">
                      <Stethoscope className="h-3 w-3" /> Dr. {a.doctors?.first_name} {a.doctors?.last_name}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" /> {formatTime(a.appointment_date)}
                    </span>
                  </div>
                  {a.reason && <p className="mt-1 text-xs text-slate-500">{a.reason}</p>}
                </div>
              </div>

              <div className="flex items-center justify-between gap-3 sm:justify-end">
                <Badge status={a.status} />
                <div className="flex gap-1">
                  <button onClick={() => openEdit(a)} className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-slate-100 hover:text-teal-600">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button onClick={() => setDeleteTarget(a)} className="rounded-lg p-2 text-slate-400 transition-colors hover:bg-rose-50 hover:text-rose-600">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add/Edit modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Edit Appointment' : 'Add Appointment'}>
        <div className="space-y-4">
          <FormField label="Patient" required>
            <Select value={form.patient_id} onChange={(e) => setForm({ ...form, patient_id: e.target.value })}>
              <option value="">Select a patient</option>
              {patients.map((p) => (
                <option key={p.id} value={p.id}>{p.first_name} {p.last_name}</option>
              ))}
            </Select>
          </FormField>
          <FormField label="Doctor" required>
            <Select value={form.doctor_id} onChange={(e) => setForm({ ...form, doctor_id: e.target.value })}>
              <option value="">Select a doctor</option>
              {doctors.map((d) => (
                <option key={d.id} value={d.id}>Dr. {d.first_name} {d.last_name} — {d.specialization}</option>
              ))}
            </Select>
          </FormField>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <FormField label="Date & Time" required>
              <TextInput type="datetime-local" value={form.appointment_date} onChange={(e) => setForm({ ...form, appointment_date: e.target.value })} />
            </FormField>
            <FormField label="Status">
              <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                {APPOINTMENT_STATUSES.map((s) => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
              </Select>
            </FormField>
          </div>
          <FormField label="Reason for Visit">
            <TextInput value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} placeholder="e.g. Annual checkup" />
          </FormField>
          <FormField label="Notes">
            <TextArea rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Additional notes..." />
          </FormField>
          {error && <p className="rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-600">{error}</p>}
          <div className="flex justify-end gap-3 pt-2">
            <button onClick={() => setModalOpen(false)} className="rounded-lg px-4 py-2.5 text-sm font-medium text-slate-600 hover:bg-slate-100">
              Cancel
            </button>
            <button
              onClick={save}
              disabled={saving}
              className="rounded-lg bg-teal-600 px-5 py-2.5 text-sm font-semibold text-white shadow-lg shadow-teal-600/20 transition-colors hover:bg-teal-700 disabled:opacity-50"
            >
              {saving ? 'Saving...' : editing ? 'Save Changes' : 'Add Appointment'}
            </button>
          </div>
        </div>
      </Modal>

      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDelete}
        title="Delete Appointment"
        message={`Are you sure you want to delete this appointment for ${deleteTarget?.patients?.first_name} ${deleteTarget?.patients?.last_name}? This cannot be undone.`}
      />
    </div>
  );
}
