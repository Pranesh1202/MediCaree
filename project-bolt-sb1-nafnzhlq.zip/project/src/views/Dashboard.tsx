import {
  Users,
  Stethoscope,
  CalendarDays,
  TrendingUp,
  Clock,
  CheckCircle2,
  XCircle,
  ArrowRight,
} from 'lucide-react';
import { type Patient, type Doctor, type AppointmentWithRelations } from '@/lib/supabase';
import { Badge, Spinner } from '@/components/ui';

type Props = {
  patients: Patient[];
  doctors: Doctor[];
  appointments: AppointmentWithRelations[];
  loading: boolean;
  onNavigate: (view: 'dashboard' | 'patients' | 'doctors' | 'appointments') => void;
};

export function Dashboard({ patients, doctors, appointments, loading, onNavigate }: Props) {
  if (loading) return <Spinner />;

  const activePatients = patients.filter((p) => p.status === 'active').length;
  const activeDoctors = doctors.filter((d) => d.status === 'active').length;
  const scheduledAppts = appointments.filter((a) => a.status === 'scheduled').length;
  const completedAppts = appointments.filter((a) => a.status === 'completed').length;

  const upcoming = appointments
    .filter((a) => a.status === 'scheduled' && new Date(a.appointment_date) >= new Date())
    .slice(0, 5);

  const recent = appointments.slice().reverse().slice(0, 5);

  const stats = [
    {
      label: 'Total Patients',
      value: patients.length,
      sub: `${activePatients} active`,
      icon: Users,
      color: 'teal',
      onClick: () => onNavigate('patients'),
    },
    {
      label: 'Total Doctors',
      value: doctors.length,
      sub: `${activeDoctors} active`,
      icon: Stethoscope,
      color: 'blue',
      onClick: () => onNavigate('doctors'),
    },
    {
      label: 'Appointments',
      value: appointments.length,
      sub: `${scheduledAppts} scheduled`,
      icon: CalendarDays,
      color: 'amber',
      onClick: () => onNavigate('appointments'),
    },
    {
      label: 'Completed',
      value: completedAppts,
      sub: 'visits finished',
      icon: CheckCircle2,
      color: 'emerald',
      onClick: () => onNavigate('appointments'),
    },
  ];

  const colorMap: Record<string, string> = {
    teal: 'bg-teal-50 text-teal-600 ring-teal-600/10',
    blue: 'bg-blue-50 text-blue-600 ring-blue-600/10',
    amber: 'bg-amber-50 text-amber-600 ring-amber-600/10',
    emerald: 'bg-emerald-50 text-emerald-600 ring-emerald-600/10',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Dashboard</h1>
        <p className="mt-1 text-sm text-slate-500">Overview of your hospital management system</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <button
              key={s.label}
              onClick={s.onClick}
              className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-5 text-left shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-md"
            >
              <div className="flex items-center justify-between">
                <div className={`flex h-11 w-11 items-center justify-center rounded-xl ring-1 ${colorMap[s.color]}`}>
                  <Icon className="h-5 w-5" />
                </div>
                <ArrowRight className="h-4 w-4 text-slate-300 transition-transform group-hover:translate-x-1 group-hover:text-slate-400" />
              </div>
              <p className="mt-4 text-3xl font-bold tracking-tight text-slate-900">{s.value}</p>
              <p className="mt-1 text-sm font-medium text-slate-600">{s.label}</p>
              <p className="mt-0.5 text-xs text-slate-400">{s.sub}</p>
            </button>
          );
        })}
      </div>

      {/* Two columns */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Upcoming appointments */}
        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-teal-600" />
              <h2 className="text-sm font-semibold text-slate-900">Upcoming Appointments</h2>
            </div>
            <button
              onClick={() => onNavigate('appointments')}
              className="text-xs font-medium text-teal-600 hover:text-teal-700"
            >
              View all
            </button>
          </div>
          <div className="divide-y divide-slate-50">
            {upcoming.length === 0 && (
              <p className="px-5 py-8 text-center text-sm text-slate-400">No upcoming appointments</p>
            )}
            {upcoming.map((a) => (
              <div key={a.id} className="flex items-center justify-between px-5 py-3.5">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-slate-800">
                    {a.patients?.first_name} {a.patients?.last_name}
                  </p>
                  <p className="mt-0.5 truncate text-xs text-slate-400">
                    Dr. {a.doctors?.first_name} {a.doctors?.last_name} · {a.doctors?.specialization}
                  </p>
                </div>
                <div className="ml-4 flex flex-col items-end gap-1">
                  <span className="text-xs font-medium text-slate-600">
                    {new Date(a.appointment_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </span>
                  <span className="text-xs text-slate-400">
                    {new Date(a.appointment_date).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent activity */}
        <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-teal-600" />
              <h2 className="text-sm font-semibold text-slate-900">Recent Activity</h2>
            </div>
          </div>
          <div className="divide-y divide-slate-50">
            {recent.length === 0 && (
              <p className="px-5 py-8 text-center text-sm text-slate-400">No recent activity</p>
            )}
            {recent.map((a) => (
              <div key={a.id} className="flex items-center justify-between px-5 py-3.5">
                <div className="flex items-center gap-3 min-w-0">
                  {a.status === 'completed' ? (
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-500" />
                  ) : a.status === 'cancelled' ? (
                    <XCircle className="h-4 w-4 shrink-0 text-rose-500" />
                  ) : (
                    <CalendarDays className="h-4 w-4 shrink-0 text-blue-500" />
                  )}
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-slate-800">
                      {a.patients?.first_name} {a.patients?.last_name}
                    </p>
                    <p className="truncate text-xs text-slate-400">{a.reason || 'General consultation'}</p>
                  </div>
                </div>
                <Badge status={a.status} />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Doctor summary */}
      <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="border-b border-slate-100 px-5 py-4">
          <div className="flex items-center gap-2">
            <Stethoscope className="h-4 w-4 text-teal-600" />
            <h2 className="text-sm font-semibold text-slate-900">Doctors by Specialization</h2>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4 p-5 sm:grid-cols-3 lg:grid-cols-5">
          {Object.entries(
            doctors.reduce<Record<string, number>>((acc, d) => {
              acc[d.specialization] = (acc[d.specialization] ?? 0) + 1;
              return acc;
            }, {})
          ).map(([spec, count]) => (
            <div key={spec} className="rounded-xl border border-slate-100 bg-slate-50 p-4">
              <p className="text-2xl font-bold text-slate-900">{count}</p>
              <p className="mt-0.5 text-xs font-medium text-slate-500">{spec}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
