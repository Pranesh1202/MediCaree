export const PATIENT_STATUSES = ['active', 'discharged', 'deceased'] as const;
export const DOCTOR_STATUSES = ['active', 'on-leave', 'inactive'] as const;
export const APPOINTMENT_STATUSES = ['scheduled', 'completed', 'cancelled', 'no-show'] as const;
export const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as const;
export const GENDERS = ['male', 'female', 'other'] as const;

export const SPECIALIZATIONS = [
  'Cardiology',
  'Neurology',
  'Pediatrics',
  'Orthopedics',
  'Dermatology',
  'Oncology',
  'General Medicine',
  'Psychiatry',
  'Radiology',
  'Emergency Medicine',
] as const;

export const STATUS_STYLES: Record<string, string> = {
  active: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  discharged: 'bg-amber-100 text-amber-700 border-amber-200',
  deceased: 'bg-rose-100 text-rose-700 border-rose-200',
  'on-leave': 'bg-amber-100 text-amber-700 border-amber-200',
  inactive: 'bg-slate-200 text-slate-600 border-slate-300',
  scheduled: 'bg-blue-100 text-blue-700 border-blue-200',
  completed: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  cancelled: 'bg-rose-100 text-rose-700 border-rose-200',
  'no-show': 'bg-slate-200 text-slate-600 border-slate-300',
};
