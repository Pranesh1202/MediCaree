import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Patient = {
  id: string;
  first_name: string;
  last_name: string;
  email: string | null;
  phone: string | null;
  gender: string | null;
  date_of_birth: string | null;
  address: string | null;
  blood_group: string | null;
  status: string;
  created_at: string;
};

export type Doctor = {
  id: string;
  first_name: string;
  last_name: string;
  email: string | null;
  phone: string | null;
  specialization: string;
  license_number: string | null;
  gender: string | null;
  status: string;
  created_at: string;
};

export type Appointment = {
  id: string;
  patient_id: string;
  doctor_id: string;
  appointment_date: string;
  reason: string | null;
  status: string;
  notes: string | null;
  created_at: string;
};

export type AppointmentWithRelations = Appointment & {
  patients: Pick<Patient, 'first_name' | 'last_name'> | null;
  doctors: Pick<Doctor, 'first_name' | 'last_name' | 'specialization'> | null;
};
