/*
# Hospital Management System — Core Schema

Creates the three core tables for a hospital management system that tracks
patients, doctors, and appointments. This is a single-tenant app with no
sign-in screen, so all data is intentionally shared and policies allow both
the anon and authenticated roles full CRUD access.

## 1. New Tables

### patients
- `id` (uuid, primary key)
- `first_name` (text, not null) — patient's first name
- `last_name` (text, not null) — patient's last name
- `email` (text) — contact email
- `phone` (text) — contact phone number
- `gender` (text) — male / female / other
- `date_of_birth` (date) — patient's date of birth
- `address` (text) — home address
- `blood_group` (text) — blood type (A+, A-, B+, B-, AB+, AB-, O+, O-)
- `status` (text, default 'active') — active / discharged / deceased
- `created_at` (timestamptz, default now())

### doctors
- `id` (uuid, primary key)
- `first_name` (text, not null) — doctor's first name
- `last_name` (text, not null) — doctor's last name
- `email` (text, unique) — contact email
- `phone` (text) — contact phone number
- `specialization` (text, not null) — area of expertise (e.g. Cardiology)
- `license_number` (text, unique) — medical license number
- `gender` (text) — male / female / other
- `status` (text, default 'active') — active / on-leave / inactive
- `created_at` (timestamptz, default now())

### appointments
- `id` (uuid, primary key)
- `patient_id` (uuid, foreign key → patients.id, on delete cascade)
- `doctor_id` (uuid, foreign key → doctors.id, on delete cascade)
- `appointment_date` (timestamptz, not null) — scheduled date & time
- `reason` (text) — reason for the visit
- `status` (text, default 'scheduled') — scheduled / completed / cancelled / no-show
- `notes` (text) — additional notes
- `created_at` (timestamptz, default now())

## 2. Indexes
- `idx_appointments_patient_id` on appointments(patient_id)
- `idx_appointments_doctor_id` on appointments(doctor_id)
- `idx_appointments_date` on appointments(appointment_date)
- `idx_patients_status` on patients(status)
- `idx_doctors_specialization` on doctors(specialization)

## 3. Security (RLS)
All three tables have RLS enabled with permissive policies for the anon and
authenticated roles because this is a single-tenant, no-auth app where the
data is intentionally shared.
*/

-- Patients
CREATE TABLE IF NOT EXISTS patients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text,
  phone text,
  gender text CHECK (gender IN ('male', 'female', 'other')),
  date_of_birth date,
  address text,
  blood_group text CHECK (blood_group IN ('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', '')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'discharged', 'deceased')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE patients ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_patients" ON patients;
CREATE POLICY "anon_select_patients" ON patients FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_patients" ON patients;
CREATE POLICY "anon_insert_patients" ON patients FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_patients" ON patients;
CREATE POLICY "anon_update_patients" ON patients FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_patients" ON patients;
CREATE POLICY "anon_delete_patients" ON patients FOR DELETE
  TO anon, authenticated USING (true);

-- Doctors
CREATE TABLE IF NOT EXISTS doctors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  first_name text NOT NULL,
  last_name text NOT NULL,
  email text UNIQUE,
  phone text,
  specialization text NOT NULL,
  license_number text UNIQUE,
  gender text CHECK (gender IN ('male', 'female', 'other')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'on-leave', 'inactive')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE doctors ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_doctors" ON doctors;
CREATE POLICY "anon_select_doctors" ON doctors FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_doctors" ON doctors;
CREATE POLICY "anon_insert_doctors" ON doctors FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_doctors" ON doctors;
CREATE POLICY "anon_update_doctors" ON doctors FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_doctors" ON doctors;
CREATE POLICY "anon_delete_doctors" ON doctors FOR DELETE
  TO anon, authenticated USING (true);

-- Appointments
CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  doctor_id uuid NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
  appointment_date timestamptz NOT NULL,
  reason text,
  status text NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled', 'no-show')),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_appointments" ON appointments;
CREATE POLICY "anon_select_appointments" ON appointments FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_appointments" ON appointments;
CREATE POLICY "anon_insert_appointments" ON appointments FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_appointments" ON appointments;
CREATE POLICY "anon_update_appointments" ON appointments FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_appointments" ON appointments;
CREATE POLICY "anon_delete_appointments" ON appointments FOR DELETE
  TO anon, authenticated USING (true);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_doctor_id ON appointments(doctor_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_patients_status ON patients(status);
CREATE INDEX IF NOT EXISTS idx_doctors_specialization ON doctors(specialization);
